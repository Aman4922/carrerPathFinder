$(document).ready(function() {
  // Form submission for login
  $("#log").click(function(event) {
      event.preventDefault(); // Prevent default form submission
      var email = $("#email").val();
      var password = $("#password").val();
      // Here you would typically perform validation and authentication
      // For demonstration purposes, let's assume the login is successful
      // Redirect to interest.html
      window.location.href = "interest.html";
  });

  // Form submission for signup
  $("#signinn").click(function(event) {
      event.preventDefault(); // Prevent default form submission
      var firstName = $("#firstname").val();
      var lastName = $("#lastname").val();
      var email = $("#email").val();
      var password = $("#password").val();
      var confirmPassword = $("#Cpassword").val();
      // Here you would typically perform validation and registration logic
      // For demonstration purposes, let's assume the registration is successful
      // Redirect to interest.html after registration
      window.location.href = "interest.html";
  });

  // Show signup form when "Sign up here" link is clicked
  $("#signup").click(function() {
      $("#first").slideUp("slow", function() {
          $("#second").slideDown("slow");
      });
  });

  // Show login form when "Already have an account?" link is clicked
  $("#signin").click(function() {
      $("#second").slideUp("slow", function() {
          $("#first").slideDown("slow");
      });
  });
});
